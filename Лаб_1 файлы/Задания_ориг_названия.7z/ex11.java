class ex11
{
	static double a =10.0, b=4.0, c;
	public static double hyp(){
		return c = Math.log(a*a + b*b);
		}
	public static void main(String[] args) {
		Double d = Math.exp(b*Math.log(a));
		System.out.println("katet Р°=" + a);
		System.out.println("katet b=" + b);
		System.out.println("hypotenuse С=" + hyp());
		System.out.println("A^b=" + d);
	}
}
